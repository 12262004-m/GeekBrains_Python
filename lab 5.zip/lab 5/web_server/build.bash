#!/bin/bash

sudo docker build -t server-image .
