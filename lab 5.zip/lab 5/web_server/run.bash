#!/bin/bash

docker run --name webserver -d -p 80:80 server-image
