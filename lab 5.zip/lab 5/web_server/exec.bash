#!/bin/bash

docker exec -it server-image /bin/bash
